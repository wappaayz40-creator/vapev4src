package gg.vape.account;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import gg.vape.Vape;
import gg.vape.account.LicenseInfo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LicenseInfoClient {
    HttpURLConnection connection;
    private final Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();

    public LicenseInfo fetchLicenseInfo(String licenseKey) {
        // No-auth mode: never contact thealtening, always report a valid license.
        return LicenseInfo.unlocked();
    }

    private static Exception preserveException(Exception error) {
        return error;
    }
}
