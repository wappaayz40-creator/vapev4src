package gg.vape.api;

import gg.vape.runtime.NativeBridge;

public class ApiAccessTokenProvider {
    private static String cachedAccessToken = "0";
    private static String opaqueMarker;

    public static void setOpaqueMarker(String marker) {
        opaqueMarker = marker;
    }

    public static String getAccessToken() {
        try {
            String token = NativeBridge.gat();
            if (token != null && !token.trim().isEmpty()) {
                cachedAccessToken = token;
            }
        } catch (Throwable ignored) {
        }
        return cachedAccessToken == null || cachedAccessToken.trim().isEmpty()
                ? "0" : cachedAccessToken;
    }

    public static String getOpaqueMarker() {
        return opaqueMarker;
    }


    static {
        if (ApiAccessTokenProvider.getOpaqueMarker() == null) {
            ApiAccessTokenProvider.setOpaqueMarker("Sx5Qoc");
        }
    }
}

