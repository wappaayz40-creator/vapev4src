package gg.vape.api;

import com.google.gson.JsonElement;
import gg.vape.account.AccountInfoResponse;
import gg.vape.api.ApiAccessTokenProvider;
import gg.vape.api.ApiHttpClient;
import gg.vape.api.ApiResponse;
import gg.vape.api.PublicProfileApi;
import gg.vape.api.SettingsApi;
import gg.vape.api.UserDataApi;
import gg.vape.ui.click.component.GuiComponent;
import java.util.concurrent.CompletableFuture;

public class ApiServices {
    private final String baseUrl;
    private final UserDataApi userDataApi;
    private final PublicProfileApi publicProfileApi;
    private static ApiServices instance;
    private static GuiComponent[] legacyComponentState;
    private final SettingsApi settingsApi;

    public PublicProfileApi getPublicProfileApi() {
        return this.publicProfileApi;
    }

    public CompletableFuture<ApiResponse<AccountInfoResponse>> getAccountInfo() {
        String accessToken = ApiAccessTokenProvider.getAccessToken();
        return CompletableFuture.supplyAsync(() -> this.requestAccountInfo(accessToken));
    }

    public static GuiComponent[] getLegacyComponentState() {
        return legacyComponentState;
    }

    private ApiResponse requestRegistration(String registrationCode) {
        try {
            String accessToken = ApiAccessTokenProvider.getAccessToken();
            String username = java.net.URLEncoder.encode(registrationCode, "UTF-8");
            return ApiHttpClient.getApiResponse(this.baseUrl + "/api/v1/" + accessToken
                    + "/register/" + username, JsonElement::getAsBoolean);
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static ApiServices getInstance() {
        return instance;
    }

    private ApiResponse requestAccountInfo(String accessToken) {
        try {
            return ApiHttpClient.getApiResponse(this.baseUrl + "/api/v1/" + accessToken
                    + "/authenticated", AccountInfoResponse::fromJson);
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public SettingsApi getSettingsApi() {
        return this.settingsApi;
    }

    public CompletableFuture<ApiResponse<Boolean>> registerOnlineAccount(String registrationCode) {
        return CompletableFuture.supplyAsync(() -> this.requestRegistration(registrationCode));
    }

    public ApiServices() {
        this.baseUrl = ApiServices.resolveBaseUrl();
        this.getClass();
        this.publicProfileApi = new PublicProfileApi(this.baseUrl);
        this.getClass();
        this.settingsApi = new SettingsApi(this.baseUrl);
        this.getClass();
        this.userDataApi = new UserDataApi(this.baseUrl);
    }

    private static String resolveBaseUrl() {
        // Offline build: Vape Online is disabled and cannot be pointed at
        // another backend.
        return "https://offline.invalid/api";
    }

    static {
        ApiServices.setLegacyComponentState(new GuiComponent[4]);
        instance = new ApiServices();
    }

    public static void setLegacyComponentState(GuiComponent[] state) {
        legacyComponentState = state;
    }

    public UserDataApi getUserDataApi() {
        return this.userDataApi;
    }
}
