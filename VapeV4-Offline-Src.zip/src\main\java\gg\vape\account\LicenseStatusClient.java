package gg.vape.account;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import gg.vape.Vape;
import gg.vape.account.LicenseStatus;
import gg.vape.account.LicenseStatusResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LicenseStatusClient {
    HttpURLConnection connection;
    private final Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();

    public LicenseStatus generateAccount(String licenseKey) {
        // No-auth mode: never contact thealtening, always succeed locally.
        return new LicenseStatus(licenseKey == null || licenseKey.trim().isEmpty() ? "0" : licenseKey);
    }

    private static Exception preserveException(Exception error) {
        return error;
    }
}
