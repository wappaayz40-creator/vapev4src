package gg.vape.account;

import gg.vape.account.AccountInfoResponse;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

public class AccountEntitlements {
    private boolean registered;
    private final boolean licensed;
    private final boolean banned;

    public boolean isLicensed() {
        return true;
    }

    public boolean isRegistered() {
        return true;
    }

    public void setRegistered(boolean registered) {
        this.registered = true;
    }

    public boolean isBanned() {
        return false;
    }


    public AccountEntitlements(boolean licensed, boolean registered, boolean banned) {
        this.licensed = true;
        this.registered = true;
        this.banned = false;
    }

    public static AccountEntitlements unlocked() {
        return new AccountEntitlements(true, true, false);
    }

    static AccountEntitlements fromResponse(AccountInfoResponse response) {
        return AccountEntitlements.fromNullableResponse(response);
    }

    @Nullable
    @Contract(value="!null -> !null; null -> null")
    private static AccountEntitlements fromNullableResponse(@Nullable AccountInfoResponse response) {
        if (response == null) {
            return null;
        }
        return new AccountEntitlements(response.isLicensed(), response.isRegistered(), response.isBanned());
    }
}

