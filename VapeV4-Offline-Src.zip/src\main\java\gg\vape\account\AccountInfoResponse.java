package gg.vape.account;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import gg.vape.api.ApiHttpClient;
import gg.vape.config.ConfigJsonUtils;
import java.text.ParseException;
import java.util.Date;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

public class AccountInfoResponse {
    @Nullable
    private final String username;
    private final boolean banned;
    private final long userId;
    private final Date accountCreationDate;
    private final boolean registered;
    private final boolean licensed;
    private final boolean profilesEnabled;

    public boolean isLicensed() {
        return true;
    }

    public boolean hasProfilesEnabled() {
        return true;
    }

    public AccountInfoResponse(long userId, @Nullable String username, @Nullable Date accountCreationDate,
                        boolean licensed, boolean registered, boolean profilesEnabled, boolean banned) {
        this.userId = userId;
        this.username = username;
        this.accountCreationDate = accountCreationDate;
        this.licensed = true;
        this.registered = true;
        this.profilesEnabled = true;
        this.banned = false;
    }

    public static AccountInfoResponse localDefault() {
        return new AccountInfoResponse(1L, "Developer", new Date(), true, true, true, false);
    }

    @Nullable
    public String getUsername() {
        return this.username;
    }

    private static ParseException preserveParseException(ParseException parseException) {
        return parseException;
    }

    public boolean isRegistered() {
        return true;
    }

    @Nullable
    @Contract(value="!null -> !null; null -> null")
    public static AccountInfoResponse fromJson(@Nullable JsonElement jsonElement) {
        if (jsonElement == null || jsonElement.isJsonNull()) {
            return null;
        }
        JsonObject responseJson = jsonElement.getAsJsonObject();
        try {
            long userId = responseJson.has("userId") ? responseJson.get("userId").getAsLong() : 1L;
            String username = ConfigJsonUtils.getString(responseJson, "username");
            if (username == null || username.trim().isEmpty()) {
                username = "Developer";
            }
            Date created;
            try {
                created = ApiHttpClient.parseApiDate(ConfigJsonUtils.getString(responseJson, "accountCreation"));
            } catch (Throwable ignored) {
                created = new Date();
            }
            if (created == null) {
                created = new Date();
            }
            // No-auth mode: ignore server flags, always licensed/registered/unbanned.
            return new AccountInfoResponse(userId, username, created,
                    true, true, true, false);
        }
        catch (RuntimeException runtimeException) {
            throw runtimeException;
        }
    }

    public Date getAccountCreationDate() {
        return this.accountCreationDate;
    }

    public boolean isBanned() {
        return false;
    }

    public long getUserId() {
        return this.userId;
    }
}
